# Shahriar Siddique Arjon — portfolio (v2)

React + Vite single-page portfolio. No CSS framework: one stylesheet (`src/styles.css`) with light and dark themes.

## Edit content
Everything you see on the site is in **`src/data.js`** — experience, projects, papers, skills, education, links.
Change text there; you never need to touch the components.

- The site opens in the dark theme; visitors can switch to light and their choice is remembered (`src/hooks/useTheme.js`).
- Hero typewriter words: `profile.roles`; the green badge text: `profile.availability`.
- Press `Ctrl + K` (or `/`) on the site for the command menu. Its entries are in `src/components/CommandPalette.jsx`.
- CV files: `public/cv/` (three versions; the hero "Download CV" menu lists them from `cvs` in `data.js`).
- Project screenshots: `public/projects/` — exact file names are listed in `public/projects/ADD_SCREENSHOTS_HERE.txt`.
  Missing images show a designed placeholder, so the site never looks broken.
- Your photo: `public/profile.jpg` (the old online photo is used until you add it).
- Skill slider icons and rows: `src/skillIcons.js`.
- Contact form: EmailJS keys at the top of `src/components/Contact.jsx` (the same keys as the old site).

## Run locally
```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # production build in dist/
```

## Deploy (Netlify — same as before)
Push to GitHub and connect the repo in Netlify, or drag the `dist/` folder onto Netlify.
`netlify.toml` already sets the build command and output folder.

## The hero heatmap
`src/components/HeatField.jsx` draws a Grad-CAM-style saliency map that follows the pointer —
a nod to the explainable-AI research. It sleeps when idle and shows a static map for visitors who prefer reduced motion.
