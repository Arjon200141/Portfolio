import { useEffect, useState } from "react";
import { TOGGLE_THEME } from "../events.js";

// "dark" (the default) or "light"; the visitor's choice is remembered.
export default function useTheme() {
  const [theme, setTheme] = useState(() => {
    try {
      return localStorage.getItem("theme") || "dark";
    } catch {
      return "dark";
    }
  });

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    try {
      localStorage.setItem("theme", theme);
    } catch {}
  }, [theme]);

  const isDark = theme === "dark";
  const toggle = () => setTheme(isDark ? "light" : "dark");

  // The command menu asks for a theme switch with a page event.
  useEffect(() => {
    window.addEventListener(TOGGLE_THEME, toggle);
    return () => window.removeEventListener(TOGGLE_THEME, toggle);
  });

  return [isDark, toggle];
}
