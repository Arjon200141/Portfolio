import { useEffect } from "react";

// Adds .is-in to every .reveal element as it scrolls into view.
export default function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll(".reveal");
    if (
      !("IntersectionObserver" in window) ||
      window.matchMedia("(prefers-reduced-motion: reduce)").matches
    ) {
      els.forEach((el) => el.classList.add("is-in"));
      return;
    }

    const io = new IntersectionObserver(
      (entries) =>
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-in");
            io.unobserve(entry.target);
          }
        }),
      { rootMargin: "0px 0px -8% 0px", threshold: 0.08 },
    );
    els.forEach((el) => io.observe(el));

    // Safety net for fast scrolls and anchor jumps that skip past elements.
    let timer = 0;
    const onScroll = () => {
      clearTimeout(timer);
      timer = setTimeout(
        () =>
          els.forEach((el) => {
            if (
              !el.classList.contains("is-in") &&
              el.getBoundingClientRect().top < window.innerHeight
            )
              el.classList.add("is-in");
          }),
        120,
      );
    };
    window.addEventListener("scroll", onScroll, { passive: true });

    return () => {
      io.disconnect();
      window.removeEventListener("scroll", onScroll);
      clearTimeout(timer);
    };
  }, []);
}
