import { useEffect, useState } from "react";

// Types each word, holds it, deletes it, then moves to the next.
// With reduced motion it simply shows the first word.
export default function useTypewriter(words, { type = 70, erase = 35, hold = 1800 } = {}) {
  const [text, setText] = useState(words[0] || "");

  useEffect(() => {
    if (words.length < 2) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    let i = 0;
    let n = words[0].length;
    let deleting = true;
    let timer = setTimeout(step, hold);

    function step() {
      n += deleting ? -1 : 1;
      setText(words[i].slice(0, n));

      let wait = deleting ? erase : type;
      if (deleting && n === 0) {
        deleting = false;
        i = (i + 1) % words.length;
        wait = 300;
      } else if (!deleting && n === words[i].length) {
        deleting = true;
        wait = hold;
      }
      timer = setTimeout(step, wait);
    }

    return () => clearTimeout(timer);
  }, [words, type, erase, hold]);

  return text;
}
