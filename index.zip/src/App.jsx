import Chrome from "./components/Chrome.jsx";
import CommandPalette from "./components/CommandPalette.jsx";
import Nav from "./components/Nav.jsx";
import Hero from "./components/Hero.jsx";
import Experience from "./components/Experience.jsx";
import Projects from "./components/Projects.jsx";
import Research from "./components/Research.jsx";
import Skills from "./components/Skills.jsx";
import Education from "./components/Education.jsx";
import Contact from "./components/Contact.jsx";
import Footer from "./components/Footer.jsx";
import Toast from "./components/Toast.jsx";
import useMagnetic from "./hooks/useMagnetic.js";
import useReveal from "./hooks/useReveal.js";
import useSpotlight from "./hooks/useSpotlight.js";

export default function App() {
  useReveal();
  useSpotlight();
  useMagnetic();
  return (
    <>
      <Chrome />
      <a className="skip" href="#work">
        Skip to content
      </a>
      <Nav />
      <main>
        <Hero />
        <Experience />
        <Projects />
        <Research />
        <Skills />
        <Education />
        <Contact />
      </main>
      <Footer />
      <CommandPalette />
      <Toast />
    </>
  );
}
