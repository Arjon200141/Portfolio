// Tiny page-wide events so far-apart components can talk without shared state.

export const TOAST = "app:toast";
export const TOGGLE_THEME = "app:toggle-theme";
export const OPEN_PALETTE = "app:open-palette";

export const toast = (message) =>
  window.dispatchEvent(new CustomEvent(TOAST, { detail: message }));

export const emit = (name) => window.dispatchEvent(new Event(name));

// Copies the email and confirms with a toast; falls back to opening the mail app.
export async function copyText(text, message) {
  try {
    await navigator.clipboard.writeText(text);
    toast(message);
    return true;
  } catch {
    window.location.href = `mailto:${text}`;
    return false;
  }
}
