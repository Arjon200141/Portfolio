// Everything shown on the site lives here. Edit text in this file; the components read from it.

export const profile = {
  name: "Shahriar Siddique Arjon",
  shortName: "Arjon",
  role: "Software Engineer & AI Researcher",
  // The hero types these out one after another.
  roles: [
    "Software Engineer",
    "AI Researcher",
    "Full-Stack Developer",
    "ERP & SaaS Builder",
  ],
  // Short line for the badge at the top of the hero.
  availability: "Open to software, full-stack & AI/ML roles",
  location: "Savar, Dhaka, Bangladesh",
  email: "aorjon123@gmail.com",
  phone: "+880 1706 318 283",
  phoneHref: "tel:+8801706318283",
  photo: "/profile.jpg",
  photoFallback: "https://i.ibb.co/WnG48X2/20240519-122715.png",
  intro:
    "I build the business software companies run on every day — ERP, booking and commerce systems — and I research how deep-learning models read medical images, and how to make them explain themselves.",
  status:
    "Software Engineer at Creation Plus. Open to software, full-stack and AI/ML engineering roles in Dhaka.",
  links: {
    linkedin: "https://linkedin.com/in/shahriar-siddique-arjon-cse-pust",
    github: "https://github.com/Arjon200141",
    scholar: "https://scholar.google.com/citations?user=s9tPYOwAAAAJ",
    orcid: "https://orcid.org/0009-0009-5109-2746",
    facebook: "https://www.facebook.com/shahriarsiddique.arjon.cse.200141/",
    instagram: "https://www.instagram.com/shahriar_siddique_arjon/",
  },
};

export const cv = {
  label: "Download CV",
  file: "/cv/Shahriar_Siddique_Arjon_CV.pdf",
};

export const highlights = [
  {
    value: "First author",
    detail: "Scopus Q1 journal article on explainable pneumonia detection",
  },
  {
    value: "16 papers",
    detail: "Peer-reviewed IEEE and Springer conference publications",
  },
  {
    value: "2+ years",
    detail: "Building production business software in Dhaka",
  },
];

export const experience = [
  {
    role: "Software Engineer",
    org: "Creation Plus",
    place: "Savar, Dhaka, on-site",
    period: "Nov 2025 – Present",
    current: true,
    points: [
      "Build multi-branch SaaS ERP products for schools and footwear businesses — admissions, exams and results, fee billing, accounting, payroll, inventory, ledgers and branch-wise financial reports.",
      "Developed the CosmosHoliday.com travel platform: flight and hotel API integration, B2B and B2C booking, visa tracking, admin panel and Flutter mobile app.",
      "Design and manage MySQL and Microsoft SQL Server databases across products — schemas, stored procedures, triggers and reporting queries.",
      "Maintain e-commerce platforms (Nobota, Sonali Craft, Baby Food BD) and a POS application; integrating an LLM-powered customer-chat agent that syncs catalogue and creates orders.",
    ],
    stack: [
      "Next.js",
      "React",
      "Go",
      "MySQL",
      "SQL Server",
      "Flutter",
      "Windows Server / IIS",
    ],
  },
  {
    role: "Full Stack Developer",
    org: "TechBazar24",
    place: "Dhaka, remote",
    period: "Jun 2024 – Aug 2025",
    points: [
      "Developed and maintained an e-commerce platform, a job portal and a social-awareness website with the MERN stack.",
      "Designed RESTful APIs, implemented JWT authentication and role-based access, and improved frontend performance.",
    ],
    stack: ["React", "Node.js", "Express", "MongoDB", "JWT"],
  },
  {
    role: "Undergraduate Student Researcher",
    org: "Pabna University of Science and Technology",
    place: "Pabna, on-site",
    period: "Jan 2023 – Aug 2025",
    points: [
      "Designed and evaluated CNN, Vision Transformer and hybrid models for medical-image classification across X-ray, MRI, CT, ultrasound, histopathology and dermatology data.",
      "Proposed PneumoniaNet, published as first author in a Scopus Q1 journal; applied Grad-CAM, LIME and SHAP to check that models attend to clinically relevant regions.",
    ],
    stack: ["PyTorch", "TensorFlow", "Keras", "Grad-CAM", "LIME", "SHAP"],
  },
];

export const clientProjects = [
  {
    name: "School ERP",
    kind: "Multi-school SaaS management system",
    period: "Sep 2026 – Present",
    summary:
      "One platform for many schools and branches: admission and admission tests, attendance, exams with automated results and a question bank, fee billing, accounting, staff payroll, transport and canteen, plus portals for students and guardians.",
    stack: ["Next.js", "React", "Go", "MySQL"],
    image: "/projects/CP-School-ERP.png",
    featured: true,
  },
  {
    name: "Shoe ERP",
    kind: "Multi-branch business management system",
    period: "May – Jun 2026",
    summary:
      "Purchase, sales and invoicing, stock movement across branches, customer and supplier ledgers, dues and advances, daily income and expenses (joma–khoroch, hawlad), and branch-wise financial reports.",
    stack: ["Next.js", "React", "Go", "MySQL"],
    image: "/projects/Sarkar-Shoe.png",
    featured: true,
  },
  {
    name: "Cosmos Holiday",
    kind: "Travel booking platform — web, admin and mobile",
    period: "Nov 2025 – Mar 2026",
    summary:
      "Flight and hotel API integration, B2B and B2C booking workflows, visa application and tracking, an admin panel and a Flutter mobile app.",
    stack: ["Next.js", "React", "MySQL", "Flutter", "REST APIs"],
    url: "https://cosmosholiday.com/",
    image: "/projects/Cosmos-Holiday.png",
    featured: true,
  },
];

export const ecommerce = {
  name: "E-commerce and retail",
  summary:
    "Storefronts, cart and checkout, OTP login, invoices, admin dashboards and sales and delivery reports for live online shops, plus a POS machine application.",
  stack: ["Next.js", "React", "Go", "MySQL", "SQL Server"],
  sites: [
    {
      name: "Nobota",
      url: "https://nobotabd.com/",
      note: "Home décor",
      image: "/projects/NObotabd.png",
    },
    {
      name: "Sonali Craft",
      url: "https://sonalicraft.com/",
      note: "Handicrafts",
      image: "/projects/SonaliCraft.png",
    },
    {
      name: "Baby Food BD",
      url: null,
      note: "Baby products",
      image: "/projects/Babyfood.png",
    },
    {
      name: "POS application",
      url: null,
      note: "Point of sale",
      image: "/projects/pos.webp",
    },
  ],
};

export const personalProjects = [
  {
    name: "AssetTrack Pro",
    summary:
      "Asset management for companies: role-based HR and employee views, returnable and non-returnable assets, request workflow and stock alerts.",
    stack: ["React", "Node.js", "MongoDB", "TanStack Query"],
    live: "https://assettrack-pro.web.app/",
    code: "https://github.com/Arjon200141/asset-track-pro-client",
    image: "/projects/AssetTrack-Pro.png",
  },
  {
    name: "Travel Kit",
    summary:
      "E-commerce for travel essentials with cart, online payment, order history and an admin sales dashboard.",
    stack: ["React", "Express", "MongoDB", "JWT", "Firebase"],
    live: "https://travel-kit-4df07.web.app/",
    code: "https://github.com/Arjon200141",
    image: "/projects/Travel-Kit.png",
  },
  {
    name: "Event Elevate",
    summary:
      "Event-service platform: book services, track what is pending and manage upcoming events with providers.",
    stack: ["React", "Node.js", "MongoDB", "Firebase Auth"],
    live: "https://mern-verse.web.app/",
    code: "https://github.com/Arjon200141/mern-verse-client",
    image: "/projects/event-elevate.webp",
  },
  {
    name: "Painted Palette",
    summary:
      "A marketplace where artists list arts and crafts with categories, stock status and prices; Google and GitHub sign-in.",
    stack: ["React", "Node.js", "MongoDB", "Tailwind"],
    live: "https://painted-palette-a10.web.app/",
    code: "https://github.com/Arjon200141/painted-palette-client",
    image: "/projects/painted-palette.webp",
  },
];

export const ME = "Arjon, S. S.";

export const journalArticle = {
  authors: [ME, "Yasmin, T.", "Mondol, A. K.", "Aman, N.", "Mahmood, S."],
  title:
    "A Novel PneumoniaNet Framework Integrating Explainable AI for Pediatric Pneumonia Detection from Chest X-rays",
  venue: "Artificial Intelligence and Applications",
  year: 2026,
  doi: "10.47852/bonviewAIA62028511",
  badges: ["First author", "Scopus Q1"],
};

export const inRevision = {
  authors: ["Yasmin, T.", ME, "Antor, N. R.", "Aman, N.", "Hossain, M. N."],
  title:
    "Efficient and Interpretable Pavement Crack Classification via SylphNet: Systematic Hyperparameter Analysis on a Primary Road Image Dataset",
  venue: "Artificial Intelligence for Engineering (Wiley)",
  status: "Minor revision",
};

export const conferencePapers = [
  {
    first: true,
    topic: "MRI",
    authors: [
      ME,
      "Yasmin, T.",
      "Mondol, A. K.",
      "Haque, M. R.",
      "Uddin, M. R.",
      "Aman, N.",
    ],
    title:
      "A Novel Hybrid Deep Learning Model for Alzheimer’s Disease Stage Classification Using MRI",
    venue: "IEEE COMPAS",
    year: 2025,
    doi: "10.1109/COMPAS67506.2025.11381658",
  },
  {
    first: true,
    topic: "MRI",
    authors: [
      ME,
      "Yasmin, T.",
      "Mondol, A. K.",
      "Haque, M. R.",
      "Uddin, M. R.",
      "Aman, N.",
    ],
    title:
      "Explainable Deep CNN Framework for Clinically Transparent and Accurate Brain Tumor Classification from MRI",
    venue: "IEEE ICCIT",
    year: 2025,
    doi: "10.1109/ICCIT68739.2025.11490136",
  },
  {
    first: true,
    topic: "Skin",
    authors: [
      ME,
      "Yasmin, T.",
      "Mondol, A. K.",
      "Uddin, M. R.",
      "Mahmood, S.",
      "Aman, N.",
    ],
    title:
      "Comprehensive Analysis of Deep Transfer Learning Models for Skin Disease Classification with Explainable AI",
    venue: "IEEE QPAIN",
    year: 2025,
    doi: "10.1109/QPAIN66474.2025.11171638",
  },
  {
    topic: "Chest X-ray",
    authors: [
      "Yasmin, T.",
      ME,
      "Mondol, A. K.",
      "Haque, M. R.",
      "Uddin, M. R.",
      "Aman, N.",
    ],
    title:
      "Deep Learning-Based Automated Detection of Tuberculosis from Chest X-Rays: A Comparative Study of State-of-the-Art Architectures",
    venue: "IEEE ICCIT",
    year: 2025,
    doi: "10.1109/ICCIT68739.2025.11491176",
  },
  {
    topic: "Skin",
    authors: [
      "Yasmin, T.",
      ME,
      "Mondol, A. K.",
      "Haque, M. R.",
      "Uddin, M. R.",
      "Aman, N.",
    ],
    title:
      "Melanoma Classification Using CNNs and Vision Transformers with Explainable AI",
    venue: "IEEE ICCIT",
    year: 2025,
    doi: "10.1109/ICCIT68739.2025.11490099",
  },
  {
    topic: "Chest X-ray",
    authors: ["Yasmin, T.", ME, "Mondol, A. K.", "Aman, N.", "Mahmood, S."],
    title: "Pneumonia Detection from Chest X-Ray Images Based on Deep Learning",
    venue: "ICDSAIA, Springer CCIS",
    year: 2025,
    doi: "10.1007/978-3-032-11352-8_18",
  },
  {
    topic: "MRI",
    authors: ["Yasmin, T.", ME, "Uddin, M. R.", "Hasnat, I."],
    title:
      "Convolutional Neural Network Based Tumor Classification Using Brain MRI Images",
    venue: "IEEE QPAIN",
    year: 2025,
    doi: "10.1109/QPAIN66474.2025.11171990",
  },
  {
    topic: "Ultrasound",
    authors: [
      "Tasnim, N.",
      ME,
      "Yasmin, T.",
      "Antor, N. R.",
      "Ahmad, A. A.",
      "Sakib, M. A.",
    ],
    title:
      "Advanced Deep Learning Framework for Ultrasound Breast Cancer Classification Using CNNs and Vision Transformers with Explainable AI",
    venue: "IEEE QPAIN",
    year: 2026,
    doi: "10.1109/QPAIN69676.2026.11546369",
  },
  {
    topic: "CT",
    authors: [
      "Uddin, M. R.",
      ME,
      "Yasmin, T.",
      "Roy, U.",
      "Haque, M. R.",
      "Rahim, M. A.",
      "Aman, N.",
      "Miah, A. S. M.",
      "Shin, J.",
    ],
    title:
      "Deep Learning Approaches for Lung Cancer Detection: A Comprehensive Evaluation of CNN",
    venue: "IEEE QPAIN",
    year: 2025,
    doi: "10.1109/QPAIN66474.2025.11171740",
  },
  {
    topic: "Chest X-ray",
    authors: [
      "Pandit, S. K.",
      ME,
      "Yasmin, T.",
      "Podder, N. K.",
      "Aman, N.",
      "Biplob, M. H.",
    ],
    title:
      "Explainable Deep Learning for Lung Disease Detection: A Comparative Study Using Grad-CAM",
    venue: "IEEE ICCIT",
    year: 2025,
    doi: "10.1109/ICCIT68739.2025.11490541",
  },
  {
    topic: "Other",
    authors: [
      "Yasmin, T.",
      "Tasnim, N.",
      "Antor, N. R.",
      ME,
      "Ahmad, A. A.",
      "Dutta, D.",
    ],
    title:
      "Explainable Gait Angle Classification Using CNNs and Vision Transformers with Attention-Based Interpretability",
    venue: "IEEE QPAIN",
    year: 2026,
    doi: "10.1109/QPAIN69676.2026.11546027",
  },
  {
    topic: "Other",
    authors: [
      "Mondol, A. K.",
      "Das, D.",
      "Yasmin, T.",
      ME,
      "Iqbal, S. M. H. S.",
      "Aman, N.",
    ],
    title:
      "Support Vector Machine Model for Enhancing the Accuracy of Chronic Kidney Disease Risk Prediction",
    venue: "IEEE QPAIN",
    year: 2025,
    doi: "10.1109/QPAIN66474.2025.11172008",
  },
  {
    topic: "Skin",
    authors: [
      "Antor, M. S. U. M.",
      "Podder, N. K.",
      "Aman, N.",
      "Haque, M. R.",
      ME,
      "Yasmin, T.",
    ],
    title:
      "Comparative Deep Learning and Explainable AI Approaches for Automated Detection of Arsenic Skin Lesions",
    venue: "IEEE COMPAS",
    year: 2025,
    doi: "10.1109/COMPAS67506.2025.11381857",
  },
  {
    topic: "Other",
    authors: [
      "Azam, M. Z.",
      "Asfaq, S.",
      "Antor, N. R.",
      "Tasnim, N.",
      ME,
      "Yasmin, T.",
    ],
    title:
      "Explainable AI-Based Deep Learning Approach for Asphalt Pavement Crack Detection",
    venue: "IEEE ICECTE",
    year: 2026,
    doi: "10.1109/ICECTE69292.2026.11429202",
  },
  {
    topic: "Chest X-ray",
    authors: [
      "Haque, M. R.",
      "Islam, M. R.",
      ME,
      "Antor, M. S. U. M.",
      "Yasmin, T.",
      "Uddin, M. R.",
    ],
    title:
      "Performance Comparison of CNN Architectures for Multi-class Chest X-Ray Classification of COVID-19 and Pneumonia",
    venue: "BIM, Springer LNNS",
    year: 2025,
    doi: "10.1007/978-3-032-15346-3_21",
  },
  {
    topic: "MRI",
    authors: ["Mondol, A. K.", "Iqbal, S. M. H. S.", ME, "Yasmin, T."],
    title:
      "Logistic Regression-Based Machine Learning Model for Early Alzheimer's Detection Using the OASIS Dataset",
    venue: "ICDSAIA, Springer CCIS",
    year: 2025,
    doi: "10.1007/978-3-032-11355-9_15",
  },
];

export const skillGroups = [
  {
    group: "Frontend",
    items: [
      "Next.js",
      "React",
      "JavaScript",
      "Tailwind CSS",
      "TanStack Query",
      "HTML",
      "CSS",
    ],
  },
  {
    group: "Backend",
    items: [
      "Go",
      "Node.js",
      "Express",
      "REST APIs",
      "JWT and role-based access",
      "Third-party API integration",
    ],
  },
  {
    group: "Databases",
    items: [
      "MySQL",
      "Microsoft SQL Server",
      "Stored procedures and triggers",
      "Reporting queries",
      "MongoDB",
      "Firebase",
    ],
  },
  {
    group: "Mobile and deployment",
    items: ["Flutter", "Windows Server", "IIS", "Git and GitHub"],
  },
  {
    group: "Machine learning",
    items: [
      "PyTorch",
      "TensorFlow",
      "Keras",
      "CNNs",
      "Vision Transformers",
      "Transfer learning",
      "LLM integration",
    ],
  },
  {
    group: "Explainability and research",
    items: [
      "Grad-CAM",
      "LIME",
      "SHAP",
      "Medical image analysis",
      "Experimental design",
      "Scientific writing",
    ],
  },
];

export const education = [
  {
    title: "B.Sc. Engineering in Computer Science and Engineering",
    school: "Pabna University of Science and Technology",
    period: "2020 – 2025",
    result: "CGPA 3.23 / 4.00",
  },
  {
    title: "Higher Secondary Certificate, Science",
    school: "Savar Model College, Dhaka Board",
    period: "2019",
    result: "GPA 4.42 / 5.00",
  },
  {
    title: "Secondary School Certificate, Science",
    school: "Jahangirnagar University School and College, Dhaka Board",
    period: "2017",
    result: "GPA 5.00 / 5.00",
  },
];

export const activities = [
  "Assistant General Secretary, PUST Programming Club — organised inter-university programming contests.",
  "Solved 350+ competitive-programming problems on online judges.",
  "Secretary, Dhaka-Gazipur-Narayanganj Student Welfare Association, PUST.",
  "Certified in Complete Web Development (Programming Hero) and Corporate Etiquette and Email Writing (10 Minute School).",
];

// Shown after a message is sent from the contact form.
export const glance = {
  replyTime: "I usually reply within a day.",
};

export const navLinks = [
  ["work", "Experience"],
  ["projects", "Projects"],
  ["research", "Research"],
  ["skills", "Skills"],
  ["education", "Education"],
  ["contact", "Contact"],
];
