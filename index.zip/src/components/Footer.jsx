import { FaFacebook, FaGithub, FaInstagram, FaLinkedin } from "react-icons/fa6";
import { navLinks, profile } from "../data.js";

export default function Footer() {
  const links = profile.links;
  return (
    <footer className="footer">
      <div className="container footer__inner">
        <div className="footer__brand">
          <a href="#top" className="nav__brand">
            {profile.shortName}
            <span className="nav__brand-dot" aria-hidden="true" />
          </a>
          <p className="muted">{profile.role}</p>
        </div>

        <nav aria-label="Footer">
          <ul className="footer__nav">
            {navLinks.map(([id, label]) => (
              <li key={id}>
                <a href={`#${id}`}>{label}</a>
              </li>
            ))}
          </ul>
        </nav>

        <ul className="footer__social">
          <li>
            <a href={links.github} target="_blank" rel="noreferrer" aria-label="GitHub">
              <FaGithub />
            </a>
          </li>
          <li>
            <a href={links.linkedin} target="_blank" rel="noreferrer" aria-label="LinkedIn">
              <FaLinkedin />
            </a>
          </li>
          <li>
            <a href={links.facebook} target="_blank" rel="noreferrer" aria-label="Facebook">
              <FaFacebook />
            </a>
          </li>
          <li>
            <a href={links.instagram} target="_blank" rel="noreferrer" aria-label="Instagram">
              <FaInstagram />
            </a>
          </li>
        </ul>
      </div>
      <div className="container footer__base">
        <p>
          © {new Date().getFullYear()} {profile.name}
        </p>
        <p>{profile.location}</p>
      </div>
    </footer>
  );
}
