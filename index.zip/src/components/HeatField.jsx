import { useEffect, useRef } from "react";

// Grad-CAM-style colour ramp: deep indigo -> teal -> amber -> pale yellow.
const STOPS = [
  [0, 61, 52, 139],
  [0.35, 15, 139, 141],
  [0.7, 242, 165, 65],
  [1, 255, 236, 179],
];

function ramp(t) {
  for (let i = 1; i < STOPS.length; i++) {
    if (t <= STOPS[i][0]) {
      const a = STOPS[i - 1];
      const b = STOPS[i];
      const k = (t - a[0]) / (b[0] - a[0]);
      return [
        a[1] + (b[1] - a[1]) * k,
        a[2] + (b[2] - a[2]) * k,
        a[3] + (b[3] - a[3]) * k,
      ];
    }
  }
  const last = STOPS[STOPS.length - 1];
  return [last[1], last[2], last[3]];
}

const LUT = Array.from({ length: 256 }, (_, i) => ramp(i / 255));

// A saliency map that follows the pointer. It sleeps when the heat has faded
// and draws a static map for visitors who prefer reduced motion.
export default function HeatField({ targetRef, anchorRef }) {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const target = targetRef.current;
    if (!canvas || !target) return;

    const ctx = canvas.getContext("2d");
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    let W = 100;
    let H = 60;
    let heat = new Float32Array(W * H);
    let img = ctx.createImageData(W, H);
    let raf = 0;
    let running = false;
    let pointer = null;
    let pointerAt = 0;
    let start = 0;

    const resize = () => {
      const r = target.getBoundingClientRect();
      W = 100;
      H = Math.max(30, Math.round((W * r.height) / Math.max(r.width, 1)));
      canvas.width = W;
      canvas.height = H;
      heat = new Float32Array(W * H);
      img = ctx.createImageData(W, H);
    };

    const splat = (nx, ny, amount, radius) => {
      const cx = nx * W;
      const cy = ny * H;
      const r2 = radius * radius;
      const x0 = Math.max(0, Math.floor(cx - radius * 2));
      const x1 = Math.min(W - 1, Math.ceil(cx + radius * 2));
      const y0 = Math.max(0, Math.floor(cy - radius * 2));
      const y1 = Math.min(H - 1, Math.ceil(cy + radius * 2));
      for (let y = y0; y <= y1; y++)
        for (let x = x0; x <= x1; x++) {
          const d2 = (x - cx) ** 2 + (y - cy) ** 2;
          const i = y * W + x;
          heat[i] = Math.min(1, heat[i] + amount * Math.exp(-d2 / (2 * r2)));
        }
    };

    // Where the heat settles: just inside the name heading.
    const anchor = () => {
      const r = target.getBoundingClientRect();
      const a = anchorRef?.current?.getBoundingClientRect();
      return a
        ? [
            (a.left + a.width * 0.35 - r.left) / r.width,
            (a.top + a.height * 0.5 - r.top) / r.height,
          ]
        : [0.3, 0.45];
    };

    const paint = () => {
      const data = img.data;
      let peak = 0;
      for (let i = 0; i < heat.length; i++) {
        const v = heat[i];
        if (v > peak) peak = v;
        const c = LUT[(v * 255) | 0];
        const alpha = v < 0.02 ? 0 : Math.min(1, (v - 0.02) / 0.4) * 0.78;
        const p = i * 4;
        data[p] = c[0];
        data[p + 1] = c[1];
        data[p + 2] = c[2];
        data[p + 3] = alpha * 255;
      }
      ctx.putImageData(img, 0, 0);
      return peak;
    };

    const tick = (now) => {
      if (!start) start = now;
      const t = (now - start) / 1000;
      for (let i = 0; i < heat.length; i++) heat[i] *= 0.955;

      // Intro: the hot spot drifts in from the top right and settles on the name.
      if (t < 2.4) {
        const [ax, ay] = anchor();
        const k = Math.min(1, t / 2.4);
        const ease = 1 - (1 - k) ** 3;
        const x = 0.85 + (ax - 0.85) * ease + Math.sin(t * 3) * 0.04 * (1 - ease);
        const y = 0.2 + (ay - 0.2) * ease + Math.cos(t * 2.3) * 0.08 * (1 - ease);
        splat(x, y, 0.045, 4 + 2 * ease);
      }

      if (pointer && now - pointerAt < 1200) splat(pointer[0], pointer[1], 0.04, 4.5);

      if (paint() < 0.01 && t > 2.4 && (!pointer || now - pointerAt > 1200)) {
        running = false;
        return;
      }
      raf = requestAnimationFrame(tick);
    };

    const wake = () => {
      if (!running) {
        running = true;
        raf = requestAnimationFrame(tick);
      }
    };

    const onMove = (e) => {
      const r = target.getBoundingClientRect();
      pointer = [(e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height];
      pointerAt = performance.now();
      wake();
    };

    resize();
    if (reduced) {
      const [x, y] = anchor();
      splat(x, y, 0.9, 9);
      splat(x + 0.12, y - 0.08, 0.5, 7);
      paint();
    } else {
      wake();
      target.addEventListener("pointermove", onMove);
    }

    const ro = new ResizeObserver(() => {
      resize();
      if (reduced) {
        const [x, y] = anchor();
        splat(x, y, 0.9, 9);
        paint();
      } else wake();
    });
    ro.observe(target);

    return () => {
      cancelAnimationFrame(raf);
      target.removeEventListener("pointermove", onMove);
      ro.disconnect();
    };
  }, [targetRef, anchorRef]);

  return <canvas ref={canvasRef} className="heatfield" aria-hidden="true" />;
}
