import { useMemo, useState } from "react";
import { FiExternalLink } from "react-icons/fi";
import { conferencePapers, inRevision, journalArticle, ME, profile } from "../data.js";
import CountUp from "./CountUp.jsx";
import Section from "./Section.jsx";

// Summary numbers, all counted from data.js so they stay correct when papers are added.
const STATS = [
  [conferencePapers.length + 1, "Published papers"],
  [
    conferencePapers.filter((p) => p.first).length +
      (journalArticle.badges.includes("First author") ? 1 : 0),
    "As first author",
  ],
  [conferencePapers.filter((p) => p.venue.startsWith("IEEE")).length, "IEEE conference papers"],
  [conferencePapers.filter((p) => p.venue.includes("Springer")).length, "Springer papers"],
];

const PAGE = 6;
const FILTERS = ["All", "Chest X-ray", "MRI", "Skin", "Ultrasound", "CT", "Other", "First author"];

const matches = (filter) => (p) =>
  filter === "All" ? true : filter === "First author" ? p.first : p.topic === filter;

const Authors = ({ list }) => (
  <span className="authors">
    {list.map((a, i) => (
      <span key={a + i}>
        {a === ME ? <strong>{a}</strong> : a}
        {i < list.length - 1 ? ", " : ""}
      </span>
    ))}
  </span>
);

export default function Research() {
  const [filter, setFilter] = useState("All");
  const [showAll, setShowAll] = useState(false);

  const shown = useMemo(() => conferencePapers.filter(matches(filter)), [filter]);
  const count = (f) => conferencePapers.filter(matches(f)).length;

  return (
    <Section
      id="research"
      title="Research"
      lead="Deep learning and explainable AI for medical imaging: which architectures work, and whether they look at the right part of the image."
    >
      <ul className="rstats reveal" aria-label="Publication summary">
        {STATS.map(([value, label]) => (
          <li key={label}>
            <strong>
              <CountUp value={String(value)} />
            </strong>
            <span>{label}</span>
          </li>
        ))}
      </ul>

      <article className="journal glass spot reveal">
        <div className="journal__badges">
          {journalArticle.badges.map((b) => (
            <span key={b}>{b}</span>
          ))}
        </div>
        <h3>{journalArticle.title}</h3>
        <p>
          <Authors list={journalArticle.authors} />
        </p>
        <p className="muted">
          <em>{journalArticle.venue}</em>, {journalArticle.year}
        </p>
        <a
          className="textlink"
          href={`https://doi.org/${journalArticle.doi}`}
          target="_blank"
          rel="noreferrer"
        >
          Read the article <FiExternalLink aria-hidden="true" />
        </a>
      </article>

      <p className="revision">
        <span className="pill">{inRevision.status}</span>
        <span>
          <Authors list={inRevision.authors} /> “{inRevision.title}.”{" "}
          <em>{inRevision.venue}</em>.
        </span>
      </p>

      <div className="papers__head">
        <h3 className="subhead">Conference papers</h3>
        <a className="textlink" href={profile.links.scholar} target="_blank" rel="noreferrer">
          Google Scholar profile <FiExternalLink aria-hidden="true" />
        </a>
      </div>

      <div className="chips" role="group" aria-label="Filter papers by topic">
        {FILTERS.map((f) => (
          <button
            key={f}
            className={`chip ${filter === f ? "is-on" : ""}`}
            aria-pressed={filter === f}
            onClick={() => {
              setFilter(f);
              setShowAll(false);
            }}
          >
            {f} <span className="chip__n">{count(f)}</span>
          </button>
        ))}
      </div>

      <p className="muted papers__count" aria-live="polite">
        Showing {showAll ? shown.length : Math.min(PAGE, shown.length)} of {shown.length}
        {filter === "All" ? "" : ` ${filter.toLowerCase()}`} papers
      </p>

      <ul className="papers">
        {(showAll ? shown : shown.slice(0, PAGE)).map((p) => (
          <li className="paper-in spot" key={p.doi}>
            <a
              href={`https://doi.org/${p.doi}`}
              target="_blank"
              rel="noreferrer"
              className="papers__title"
            >
              {p.title}
            </a>
            <p>
              <Authors list={p.authors} />
            </p>
            <p className="muted papers__meta">
              {p.venue} · {p.year}
              <span className="papers__topic">{p.topic}</span>
            </p>
          </li>
        ))}
      </ul>

      {shown.length > PAGE && (
        <button
          className="papers__more"
          onClick={() => setShowAll(!showAll)}
          aria-expanded={showAll}
        >
          {showAll ? "Show fewer" : `Show all ${shown.length} papers`}
        </button>
      )}
    </Section>
  );
}
