import { skillGroups } from "../data.js";
import { skillIcons, skillRows } from "../skillIcons.js";
import Section from "./Section.jsx";

function SkillIcon({ name }) {
  const [Icon, color] = skillIcons[name] || [];
  return Icon ? (
    <Icon aria-hidden="true" style={color ? { color } : undefined} />
  ) : null;
}

function Chip({ name }) {
  return (
    <li className="skillchip glass">
      <SkillIcon name={name} />
      <span>{name}</span>
    </li>
  );
}

// Two copies of the track make the scroll loop seamless.
function Marquee({ items, reverse }) {
  return (
    <div className={`marquee ${reverse ? "marquee--rev" : ""}`}>
      <ul className="marquee__track">
        {items.map((n) => (
          <Chip name={n} key={n} />
        ))}
      </ul>
      <ul className="marquee__track" aria-hidden="true">
        {items.map((n) => (
          <Chip name={n} key={n + "-copy"} />
        ))}
      </ul>
    </div>
  );
}

export default function Skills() {
  return (
    <Section
      id="skills"
      title="Skills"
      lead="The tools I use for shipping software and for running experiments."
    >
      <div className="marquees reveal" aria-label="Technologies I work with">
        {skillRows.map((row, i) => (
          <Marquee items={row} reverse={i % 2 === 1} key={i} />
        ))}
      </div>

      <div className="skills">
        {skillGroups.map((g, i) => (
          <div
            className="skills__group glass spot reveal"
            style={{ "--d": `${i * 70}ms` }}
            key={g.group}
          >
            <h3>{g.group}</h3>
            <ul>
              {g.items.map((name) => (
                <li key={name}>
                  <SkillIcon name={name} />
                  {name}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </Section>
  );
}
