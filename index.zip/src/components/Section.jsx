import { navLinks } from "../data.js";

export default function Section({ id, title, lead, children }) {
  // "01", "02", ... in the same order as the menu.
  const index = navLinks.findIndex(([key]) => key === id);
  const num = index >= 0 ? String(index + 1).padStart(2, "0") : null;

  return (
    <section id={id} className="section" aria-labelledby={`${id}-title`}>
      <div className="container">
        <header className="section__head reveal">
          <div>
            {num && (
              <p className="section__eyebrow" aria-hidden="true">
                <span>{num}</span> {title}
              </p>
            )}
            <h2 id={`${id}-title`}>{title}</h2>
          </div>
          {lead && <p className="section__lead">{lead}</p>}
        </header>
        {children}
      </div>
    </section>
  );
}
