import { useEffect, useState } from "react";
import { FiCommand, FiMenu, FiMoon, FiSun, FiX } from "react-icons/fi";
import { navLinks, profile } from "../data.js";
import { OPEN_PALETTE, emit } from "../events.js";
import useTheme from "../hooks/useTheme.js";

export default function Nav() {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("");
  const [isDark, toggleTheme] = useTheme();

  // Highlight the link for the section in the middle of the viewport.
  useEffect(() => {
    const sections = navLinks
      .map(([id]) => document.getElementById(id))
      .filter(Boolean);
    const io = new IntersectionObserver(
      (entries) =>
        entries.forEach((e) => e.isIntersecting && setActive(e.target.id)),
      { rootMargin: "-45% 0px -50% 0px" },
    );
    sections.forEach((s) => io.observe(s));
    return () => io.disconnect();
  }, []);

  return (
    <header className="nav">
      <div className="nav__inner container">
        <a href="#top" className="nav__brand" onClick={() => setOpen(false)}>
          {profile.shortName}
          <span className="nav__brand-dot" aria-hidden="true" />
        </a>

        <nav aria-label="Main">
          <ul className={`nav__links ${open ? "is-open" : ""}`}>
            {navLinks.map(([id, label]) => (
              <li key={id}>
                <a
                  href={`#${id}`}
                  className={active === id ? "is-active" : ""}
                  aria-current={active === id ? "true" : undefined}
                  onClick={() => setOpen(false)}
                >
                  {label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="nav__actions">
          <button
            className="nav__k"
            onClick={() => emit(OPEN_PALETTE)}
            aria-label="Open command menu"
            title="Command menu (Ctrl + K)"
          >
            <FiCommand aria-hidden="true" />
            <kbd>K</kbd>
          </button>
          <a className="btn btn--primary btn--sm nav__cta magnetic" href="#contact">
            Hire me
          </a>
          <button
            className="icon-btn"
            onClick={toggleTheme}
            aria-label={isDark ? "Switch to light theme" : "Switch to dark theme"}
          >
            {isDark ? <FiSun /> : <FiMoon />}
          </button>
          <button
            className="icon-btn nav__menu"
            onClick={() => setOpen((o) => !o)}
            aria-expanded={open}
            aria-label="Menu"
          >
            {open ? <FiX /> : <FiMenu />}
          </button>
        </div>
      </div>
    </header>
  );
}
