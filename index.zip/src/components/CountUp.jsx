import { useEffect, useRef, useState } from "react";

// Counts the first number in `value` up from 0 when it scrolls into view.
// "16 papers" -> 0 papers ... 16 papers. Text without a number is shown as is.
export default function CountUp({ value, duration = 1400 }) {
  const ref = useRef(null);
  const match = /\d+/.exec(value);
  const target = match ? Number(match[0]) : 0;
  const [n, setN] = useState(match ? 0 : target);

  useEffect(() => {
    if (!match) return;
    const el = ref.current;
    if (
      !("IntersectionObserver" in window) ||
      window.matchMedia("(prefers-reduced-motion: reduce)").matches
    ) {
      setN(target);
      return;
    }

    let raf = 0;
    const io = new IntersectionObserver(([entry]) => {
      if (!entry.isIntersecting) return;
      io.disconnect();
      const start = performance.now();
      const tick = (now) => {
        const k = Math.min(1, (now - start) / duration);
        setN(Math.round(target * (1 - (1 - k) ** 3)));
        if (k < 1) raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    });
    io.observe(el);
    return () => {
      io.disconnect();
      cancelAnimationFrame(raf);
    };
  }, [target, duration]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!match) return <span ref={ref}>{value}</span>;
  return (
    <span ref={ref} aria-label={value}>
      {value.slice(0, match.index)}
      {n}
      {value.slice(match.index + match[0].length)}
    </span>
  );
}
