import { useState } from "react";

// An <img> that tries `src`, then `fallbackSrc`, then draws a designed
// placeholder with the label's initials so a missing file never looks broken.
export default function SmartImage({
  src,
  fallbackSrc,
  alt,
  label,
  className = "",
  ...rest
}) {
  // 0 = src, 1 = fallbackSrc, 2 = placeholder
  const [stage, setStage] = useState(src ? 0 : 2);

  if (stage === 2) {
    const initials = (label || alt || "")
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((w) => w[0])
      .join("")
      .toUpperCase();

    // Stable pseudo-random position for the glow, derived from the label.
    let hash = 0;
    for (const ch of label || "") hash = (hash * 31 + ch.charCodeAt(0)) >>> 0;
    const style = {
      "--px": `${20 + (hash % 60)}%`,
      "--py": `${22 + ((hash >> 8) % 50)}%`,
    };

    return (
      <div className={`ph ${className}`} role="img" aria-label={alt} style={style}>
        <span className="ph__initials">{initials}</span>
        <span className="ph__label">{label}</span>
      </div>
    );
  }

  return (
    <img
      className={className}
      src={stage === 0 ? src : fallbackSrc}
      alt={alt}
      loading="lazy"
      decoding="async"
      onError={() => setStage(stage === 0 && fallbackSrc ? 1 : 2)}
      {...rest}
    />
  );
}
