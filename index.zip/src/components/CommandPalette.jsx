import { useEffect, useMemo, useRef, useState } from "react";
import {
  FiArrowRight,
  FiCopy,
  FiCornerDownLeft,
  FiDownload,
  FiExternalLink,
  FiMail,
  FiMoon,
  FiSearch,
} from "react-icons/fi";
import { cv, navLinks, profile } from "../data.js";
import { OPEN_PALETTE, TOGGLE_THEME, copyText, emit } from "../events.js";

const go = (id) => document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
const open = (url) => window.open(url, "_blank", "noopener");

const ACTIONS = [
  ...navLinks.map(([id, label]) => ({
    group: "Go to",
    label,
    icon: FiArrowRight,
    run: () => go(id),
  })),
  {
    group: "Actions",
    label: "Download CV",
    icon: FiDownload,
    run: () => {
      const a = document.createElement("a");
      a.href = cv.file;
      a.download = "";
      a.click();
    },
  },
  {
    group: "Actions",
    label: "Copy email address",
    icon: FiCopy,
    run: () => copyText(profile.email, "Email address copied"),
  },
  {
    group: "Actions",
    label: "Send an email",
    icon: FiMail,
    run: () => (window.location.href = `mailto:${profile.email}`),
  },
  { group: "Actions", label: "Switch theme", icon: FiMoon, run: () => emit(TOGGLE_THEME) },
  { group: "Links", label: "GitHub", icon: FiExternalLink, run: () => open(profile.links.github) },
  { group: "Links", label: "LinkedIn", icon: FiExternalLink, run: () => open(profile.links.linkedin) },
  {
    group: "Links",
    label: "Google Scholar",
    icon: FiExternalLink,
    run: () => open(profile.links.scholar),
  },
  { group: "Links", label: "ORCID", icon: FiExternalLink, run: () => open(profile.links.orcid) },
];

// Ctrl/⌘ + K (or "/") opens a searchable list of everything the page can do.
export default function CommandPalette() {
  const [isOpen, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [active, setActive] = useState(0);
  const inputRef = useRef(null);
  const listRef = useRef(null);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    return q
      ? ACTIONS.filter((a) => `${a.group} ${a.label}`.toLowerCase().includes(q))
      : ACTIONS;
  }, [query]);

  useEffect(() => {
    const onKey = (e) => {
      const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName);
      if ((e.key === "k" || e.key === "K") && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((o) => !o);
      } else if (e.key === "/" && !typing) {
        e.preventDefault();
        setOpen(true);
      }
    };
    const onOpen = () => setOpen(true);
    window.addEventListener("keydown", onKey);
    window.addEventListener(OPEN_PALETTE, onOpen);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener(OPEN_PALETTE, onOpen);
    };
  }, []);

  useEffect(() => {
    if (!isOpen) return;
    setQuery("");
    setActive(0);
    const prev = document.activeElement;
    requestAnimationFrame(() => inputRef.current?.focus());
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "";
      prev?.focus?.();
    };
  }, [isOpen]);

  useEffect(() => setActive(0), [query]);

  useEffect(() => {
    listRef.current
      ?.querySelector(`[data-index="${active}"]`)
      ?.scrollIntoView({ block: "nearest" });
  }, [active]);

  if (!isOpen) return null;

  const run = (action) => {
    setOpen(false);
    // Let the dialog close (and focus return) before scrolling or opening tabs.
    setTimeout(action.run, 30);
  };

  const onKeyDown = (e) => {
    if (e.key === "Escape") setOpen(false);
    else if (e.key === "ArrowDown") {
      e.preventDefault();
      setActive((i) => (i + 1) % Math.max(results.length, 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActive((i) => (i - 1 + results.length) % Math.max(results.length, 1));
    } else if (e.key === "Enter" && results[active]) {
      e.preventDefault();
      run(results[active]);
    }
  };

  let lastGroup = null;

  return (
    <div className="palette" onMouseDown={(e) => e.target === e.currentTarget && setOpen(false)}>
      <div
        className="palette__box"
        role="dialog"
        aria-modal="true"
        aria-label="Command menu"
        onKeyDown={onKeyDown}
      >
        <div className="palette__search">
          <FiSearch aria-hidden="true" />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type a command or search…"
            role="combobox"
            aria-expanded="true"
            aria-controls="palette-list"
            aria-activedescendant={results[active] ? `palette-${active}` : undefined}
          />
          <kbd>Esc</kbd>
        </div>

        <ul className="palette__list" id="palette-list" role="listbox" ref={listRef}>
          {results.length === 0 && <li className="palette__empty">No results for “{query}”</li>}
          {results.map((a, i) => {
            const header = a.group !== lastGroup ? a.group : null;
            lastGroup = a.group;
            const Icon = a.icon;
            return (
              <li key={a.group + a.label} role="presentation">
                {header && <p className="palette__group">{header}</p>}
                <button
                  id={`palette-${i}`}
                  data-index={i}
                  role="option"
                  aria-selected={i === active}
                  className={`palette__item ${i === active ? "is-active" : ""}`}
                  onMouseMove={() => setActive(i)}
                  onClick={() => run(a)}
                  tabIndex={-1}
                >
                  <Icon aria-hidden="true" />
                  {a.label}
                  {i === active && <FiCornerDownLeft className="palette__enter" aria-hidden="true" />}
                </button>
              </li>
            );
          })}
        </ul>

        <p className="palette__foot">
          <span>
            <kbd>↑</kbd>
            <kbd>↓</kbd> to move
          </span>
          <span>
            <kbd>Enter</kbd> to select
          </span>
          <span>
            <kbd>Ctrl</kbd>
            <kbd>K</kbd> to toggle
          </span>
        </p>
      </div>
    </div>
  );
}
