import { useEffect, useState } from "react";
import { FiCheckCircle } from "react-icons/fi";
import { TOAST } from "../events.js";

// Shows the latest message sent with toast() for a couple of seconds.
export default function Toast() {
  const [msg, setMsg] = useState(null);

  useEffect(() => {
    let timer = 0;
    const onToast = (e) => {
      clearTimeout(timer);
      setMsg({ text: e.detail, id: Date.now() });
      timer = setTimeout(() => setMsg(null), 2400);
    };
    window.addEventListener(TOAST, onToast);
    return () => {
      window.removeEventListener(TOAST, onToast);
      clearTimeout(timer);
    };
  }, []);

  return (
    <div className="toast-region" role="status" aria-live="polite">
      {msg && (
        <p className="toast glass" key={msg.id}>
          <FiCheckCircle aria-hidden="true" /> {msg.text}
        </p>
      )}
    </div>
  );
}
