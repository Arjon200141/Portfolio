import { activities, education } from "../data.js";
import Section from "./Section.jsx";

export default function Education() {
  return (
    <Section id="education" title="Education">
      <div className="edu">
        <ol className="edu__list">
          {education.map((e) => (
            <li className="reveal" key={e.title}>
              <div className="edu__top">
                <h3>{e.title}</h3>
                <span className="muted">{e.period}</span>
              </div>
              <p>{e.school}</p>
              <p className="edu__result">{e.result}</p>
            </li>
          ))}
        </ol>

        <div className="edu__side glass spot reveal">
          <h3>Outside the classroom</h3>
          <ul className="ticks">
            {activities.map((a) => (
              <li key={a}>{a}</li>
            ))}
          </ul>
        </div>
      </div>
    </Section>
  );
}
