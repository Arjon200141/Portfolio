import { useRef, useState } from "react";
import emailjs from "@emailjs/browser";
import { FiCheck, FiCopy, FiMapPin, FiPhone } from "react-icons/fi";
import { FaGithub, FaLinkedin } from "react-icons/fa6";
import { SiGooglescholar, SiOrcid } from "react-icons/si";
import { glance, profile } from "../data.js";
import { copyText, toast } from "../events.js";
import Section from "./Section.jsx";

// EmailJS keys (same as the old site).
const EMAILJS = {
  service: "service_8b3q4ae",
  template: "template_6mmuh49",
  publicKey: "0n652HkQdIzFmImr3",
};

export default function Contact() {
  const formRef = useRef(null);
  const [copied, setCopied] = useState(false);
  const [status, setStatus] = useState("idle"); // idle | sending | sent | error
  const [, setError] = useState("");

  const copyEmail = async () => {
    if (await copyText(profile.email, "Email address copied")) {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    setStatus("sending");
    setError("");
    try {
      await emailjs.sendForm(EMAILJS.service, EMAILJS.template, formRef.current, {
        publicKey: EMAILJS.publicKey,
      });
      setStatus("sent");
      toast("Message sent — thank you!");
      formRef.current.reset();
    } catch (err) {
      console.error("EmailJS error:", err);
      setError(err?.text || err?.message || "Unknown error");
      setStatus("error");
    }
  };

  return (
    <Section
      id="contact"
      title="Contact"
      lead="For a role, a collaboration or a research question — email is the fastest way to reach me."
    >
      <div className="contact">
        <div className="contact__info reveal">
          <h3 className="contact__title">Let’s build something together.</h3>
          <p className="contact__status">
            <span className="pulse" aria-hidden="true" />
            {profile.status}
          </p>
          <div className="contact__email">
            <a href={`mailto:${profile.email}`}>{profile.email}</a>
            <button className="icon-btn" onClick={copyEmail} aria-label="Copy email address">
              {copied ? <FiCheck /> : <FiCopy />}
            </button>
          </div>
          <p>
            <FiPhone aria-hidden="true" /> <a href={profile.phoneHref}>{profile.phone}</a>
          </p>
          <p>
            <FiMapPin aria-hidden="true" /> {profile.location}
          </p>
          <ul className="contact__links">
            <li>
              <a href={profile.links.linkedin} target="_blank" rel="noreferrer">
                <FaLinkedin aria-hidden="true" /> LinkedIn
              </a>
            </li>
            <li>
              <a href={profile.links.github} target="_blank" rel="noreferrer">
                <FaGithub aria-hidden="true" /> GitHub
              </a>
            </li>
            <li>
              <a href={profile.links.scholar} target="_blank" rel="noreferrer">
                <SiGooglescholar aria-hidden="true" /> Google Scholar
              </a>
            </li>
            <li>
              <a href={profile.links.orcid} target="_blank" rel="noreferrer">
                <SiOrcid aria-hidden="true" /> ORCID
              </a>
            </li>
          </ul>
        </div>

        <form ref={formRef} onSubmit={onSubmit} className="contact__form glass spot reveal">
          <label>
            Your name
            <input name="user_name" required autoComplete="name" />
          </label>
          <label>
            Your email
            <input name="user_email" type="email" required autoComplete="email" />
          </label>
          <label>
            Message
            <textarea name="message" rows="5" required />
          </label>
          <button className="btn btn--primary magnetic" type="submit" disabled={status === "sending"}>
            {status === "sending" ? "Sending message…" : "Send message"}
          </button>
          <p className={`form__status ${status}`} role="status">
            {status === "sent" && `Message sent. ${glance.replyTime}`}
            {status === "error" && (
              <>
                The message could not be sent. Email me directly at{" "}
                <a href={`mailto:${profile.email}`}>{profile.email}</a>.
              </>
            )}
          </p>
        </form>
      </div>
    </Section>
  );
}
