import { FiExternalLink, FiGithub } from "react-icons/fi";
import { clientProjects, ecommerce, personalProjects } from "../data.js";
import Section from "./Section.jsx";
import SmartImage from "./SmartImage.jsx";

const host = (url) => url.replace(/^https?:\/\//, "").replace(/\/$/, "");

const Tags = ({ items }) => (
  <ul className="tags" aria-label="Technologies">
    {items.map((t) => (
      <li key={t}>{t}</li>
    ))}
  </ul>
);

const BrowserBar = ({ url, name }) => (
  <div className="client__bar" aria-hidden="true">
    <i />
    <i />
    <i />
    <span>{url ? host(url) : name}</span>
  </div>
);

export default function Projects() {
  return (
    <Section
      id="projects"
      title="Projects"
      lead="Systems I have built at Creation Plus, then projects I made on my own."
    >
      <div className="client">
        {clientProjects.map((p, i) => (
          <article
            className={`client__card glass spot reveal ${i % 2 ? "is-flipped" : ""}`}
            key={p.name}
          >
            <div className="client__stage">
              <div className="client__browser">
                <BrowserBar url={p.url} name={p.name} />
                <SmartImage
                  src={p.image}
                  alt={`${p.name} screenshot`}
                  label={p.name}
                  width="1904"
                  height="911"
                />
              </div>
            </div>
            <div className="client__body">
              <p className="client__period">
                <span className="client__num">{String(i + 1).padStart(2, "0")}</span>
                {p.period}
              </p>
              <h3>{p.name}</h3>
              <p className="muted client__kind">{p.kind}</p>
              <p>{p.summary}</p>
              <Tags items={p.stack} />
              {p.url && (
                <a className="textlink" href={p.url} target="_blank" rel="noreferrer">
                  Visit {host(p.url)} <FiExternalLink aria-hidden="true" />
                </a>
              )}
            </div>
          </article>
        ))}
      </div>

      <div className="commerce reveal">
        <div className="commerce__head">
          <h3>{ecommerce.name}</h3>
          <p className="muted">{ecommerce.summary}</p>
          <Tags items={ecommerce.stack} />
        </div>
        <ul className="commerce__grid">
          {ecommerce.sites.map((s, i) => (
            <li className="site glass spot reveal" style={{ "--d": `${i * 80}ms` }} key={s.name}>
              <div className="site__stage">
                <div className="site__browser">
                  <BrowserBar url={s.url} name={s.name} />
                  <SmartImage
                    src={s.image}
                    alt={`${s.name} screenshot`}
                    label={s.name}
                    className="site__img"
                    width="1904"
                    height="911"
                  />
                </div>
              </div>
              <div className="site__text">
                <div>
                  <strong>{s.name}</strong>
                  <span className="muted">{s.note}</span>
                </div>
                {s.url && (
                  <a
                    href={s.url}
                    target="_blank"
                    rel="noreferrer"
                    aria-label={`Visit ${s.name}`}
                  >
                    Visit <FiExternalLink aria-hidden="true" />
                  </a>
                )}
              </div>
            </li>
          ))}
        </ul>
      </div>

      <h3 className="subhead">Personal projects</h3>
      <div className="personal">
        {personalProjects.map((p, i) => (
          <article
            className="personal__item glass spot reveal"
            style={{ "--d": `${(i % 2) * 90}ms` }}
            key={p.name}
          >
            <a
              className="personal__shot"
              href={p.live}
              target="_blank"
              rel="noreferrer"
              tabIndex={-1}
              aria-hidden="true"
            >
              <SmartImage src={p.image} alt="" label={p.name} width="1904" height="911" />
            </a>
            <div className="personal__text">
              <h4>{p.name}</h4>
              <p>{p.summary}</p>
              <p className="personal__stack">{p.stack.join(" · ")}</p>
              <div className="personal__links">
                <a href={p.live} target="_blank" rel="noreferrer">
                  <FiExternalLink aria-hidden="true" /> Live
                </a>
                <a href={p.code} target="_blank" rel="noreferrer">
                  <FiGithub aria-hidden="true" /> Code
                </a>
              </div>
            </div>
          </article>
        ))}
      </div>
    </Section>
  );
}
