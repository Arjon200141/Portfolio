import { useRef } from "react";
import { FiArrowRight, FiDownload } from "react-icons/fi";
import { FaGithub, FaLinkedin } from "react-icons/fa6";
import { SiGo, SiGooglescholar, SiNextdotjs, SiOrcid, SiPytorch, SiReact } from "react-icons/si";
import { cv, highlights, profile } from "../data.js";
import useTypewriter from "../hooks/useTypewriter.js";
import CountUp from "./CountUp.jsx";
import HeatField from "./HeatField.jsx";
import SmartImage from "./SmartImage.jsx";

const SOCIALS = [
  ["GitHub", profile.links.github, FaGithub],
  ["LinkedIn", profile.links.linkedin, FaLinkedin],
  ["Google Scholar", profile.links.scholar, SiGooglescholar],
  ["ORCID", profile.links.orcid, SiOrcid],
];

// Small tech badges that float around the portrait.
const ORBIT = [
  ["React", SiReact, "#149eca"],
  ["Next.js", SiNextdotjs, null],
  ["Go", SiGo, "#00add8"],
  ["PyTorch", SiPytorch, "#ee4c2c"],
];

function CvButton() {
  return (
    <a className="btn btn--primary btn--glow magnetic" href={cv.file} download>
      <FiDownload aria-hidden="true" /> {cv.label}
    </a>
  );
}

export default function Hero() {
  const heroRef = useRef(null);
  const nameRef = useRef(null);
  const words = profile.name.split(" ");
  const typed = useTypewriter(profile.roles);

  return (
    <section className="hero" id="top" ref={heroRef}>
      <HeatField targetRef={heroRef} anchorRef={nameRef} />
      <div className="hero__grid-bg" aria-hidden="true" />

      <div className="container hero__grid">
        <div className="hero__text">
          <p className="hero__status enter" style={{ "--d": "0ms" }}>
            <span className="pulse" aria-hidden="true" />
            {profile.availability}
          </p>

          <h1 className="hero__name" ref={nameRef} aria-label={profile.name}>
            {words.map((w, i) => (
              <span
                className={`hero__word ${i === words.length - 1 ? "hero__word--accent" : ""}`}
                aria-hidden="true"
                key={w}
              >
                <span style={{ "--d": `${120 + i * 110}ms` }}>{w}</span>
              </span>
            ))}
          </h1>

          <p className="hero__role enter" style={{ "--d": "520ms" }}>
            <span className="sr-only">{profile.role}</span>
            <span aria-hidden="true">
              {typed}
              <span className="caret" />
            </span>
          </p>
          <p className="hero__intro enter" style={{ "--d": "620ms" }}>
            {profile.intro}
          </p>

          <div className="hero__cta enter" style={{ "--d": "720ms" }}>
            <CvButton />
            <a className="btn btn--ghost magnetic" href="#contact">
              Get in touch <FiArrowRight aria-hidden="true" className="btn__arrow" />
            </a>
          </div>

          <ul className="hero__socials enter" style={{ "--d": "820ms" }}>
            {SOCIALS.map(([label, href, Icon]) => (
              <li key={label}>
                <a href={href} target="_blank" rel="noreferrer" aria-label={label} title={label}>
                  <Icon />
                </a>
              </li>
            ))}
          </ul>
        </div>

        <figure className="hero__photo enter" style={{ "--d": "300ms" }}>
          <div className="hero__glow" aria-hidden="true" />
          <div className="hero__ring">
            <SmartImage
              src={profile.photo}
              fallbackSrc={profile.photoFallback}
              alt={`Portrait of ${profile.name}`}
              label={profile.name}
              width="420"
              height="420"
            />
          </div>
          {ORBIT.map(([label, Icon, color], i) => (
            <span className={`orbit orbit--${i + 1} glass`} key={label} aria-hidden="true">
              <Icon style={color ? { color } : undefined} />
              {label}
            </span>
          ))}
          <figcaption className="hero__badge glass">
            <strong>Creation Plus</strong>
            <span>Software Engineer</span>
          </figcaption>
        </figure>
      </div>

      <div className="container">
        <dl className="hero__facts">
          {highlights.map((h, i) => (
            <div
              className="glass spot enter"
              style={{ "--d": `${900 + i * 100}ms` }}
              key={h.value}
            >
              <dt>
                <CountUp value={h.value} />
              </dt>
              <dd>{h.detail}</dd>
            </div>
          ))}
        </dl>
      </div>

      <a href="#work" className="hero__scroll" aria-label="Scroll to the next section">
        <span />
      </a>
    </section>
  );
}
