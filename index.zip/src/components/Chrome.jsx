import { useEffect, useState } from "react";
import { FiArrowUp } from "react-icons/fi";

// Page-level decoration: background orbs, scroll progress bar, back-to-top button.
export default function Chrome() {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    let frame = 0;
    const update = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const el = document.documentElement;
        const max = el.scrollHeight - el.clientHeight;
        setProgress(max > 0 ? el.scrollTop / max : 0);
      });
    };
    update();
    window.addEventListener("scroll", update, { passive: true });
    return () => {
      window.removeEventListener("scroll", update);
      cancelAnimationFrame(frame);
    };
  }, []);

  // A soft light that follows the pointer across the page (mouse devices only).
  useEffect(() => {
    if (!window.matchMedia("(hover: hover)").matches) return;
    const root = document.documentElement;
    let frame = 0;
    const onMove = (e) => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        root.style.setProperty("--cx", `${e.clientX}px`);
        root.style.setProperty("--cy", `${e.clientY}px`);
      });
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    return () => {
      window.removeEventListener("pointermove", onMove);
      cancelAnimationFrame(frame);
    };
  }, []);

  return (
    <>
      <div className="ambient" aria-hidden="true">
        <span className="aurora" />
        <span className="orb orb--a" />
        <span className="orb orb--b" />
        <span className="orb orb--c" />
        <span className="grain" />
      </div>
      <div className="cursor-glow" aria-hidden="true" />
      <div
        className="progress"
        style={{ transform: `scaleX(${progress})` }}
        aria-hidden="true"
      />
      <a
        href="#top"
        className={`totop glass ${progress > 0.08 ? "is-shown" : ""}`}
        aria-label="Back to top"
      >
        <FiArrowUp />
      </a>
    </>
  );
}
