import { experience } from "../data.js";
import Section from "./Section.jsx";

export default function Experience() {
  return (
    <Section
      id="work"
      title="Experience"
      lead="Production software in industry, deep-learning research at university."
    >
      <ol className="timeline">
        {experience.map((job) => (
          <li
            className={`timeline__item reveal ${job.current ? "is-current" : ""}`}
            key={job.role + job.org}
          >
            <div className="timeline__when">
              <span>{job.period}</span>
              <span className="muted">{job.place}</span>
            </div>
            <div className="timeline__body glass spot">
              <h3>
                {job.role} <span className="at">at {job.org}</span>
              </h3>
              <ul className="ticks">
                {job.points.map((p) => (
                  <li key={p}>{p}</li>
                ))}
              </ul>
              <ul className="tags" aria-label="Technologies">
                {job.stack.map((s) => (
                  <li key={s}>{s}</li>
                ))}
              </ul>
            </div>
          </li>
        ))}
      </ol>
    </Section>
  );
}
